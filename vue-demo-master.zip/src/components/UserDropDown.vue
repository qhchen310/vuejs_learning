<template>
  <a-dropdown v-if="isAuthenticated">
    <a class="ant-dropdown-link" href="#"> 个人信息
      <a-icon type="down" />
    </a>
    <a-menu slot="overlay">
      <a-menu-item>
        <a href="javascript:;">更改密码</a>
      </a-menu-item>
    </a-menu>
  </a-dropdown>
  <a-menu-item v-else>
    <a-dropdown-button @click="handleButtonClick">
      {{ title + message }}
      <a-menu slot="overlay" @click="handleMenuClick">
        <a-menu-item key="1">
          <router-link to="/register">注册</router-link>
        </a-menu-item>
        <a-menu-item key="2">
          <router-link to="/login">登录</router-link>
        </a-menu-item>
        <a-menu-item>
          <router-link to="/test">测试功能</router-link>
        </a-menu-item>
      </a-menu>
      <a-icon slot="icon" type="user" />
    </a-dropdown-button>
  </a-menu-item>
</template>

<script>
import { mapState } from "vuex";

export default {
  computed: mapState(["isAuthenticated", "userInfo"]),
  props: { mode: Number },
  methods: {
    handleButtonClick(e) {
      window.console.log("click left button", e);
      this.resetMessage("menu");
    },
    handleMenuClick(e) {
      window.console.log("click", e);
    },
    resetMessage: function (msg) {
      this.message = msg;
    },
  },
  watch: {
    message: function (val, oldVal) {
      window.console.log(`data.message trigger:new:${val},old:${oldVal}`);
    },
  },
  data() {
    return {
      title: "Menu",
      message: "",
    };
  },
};
</script>