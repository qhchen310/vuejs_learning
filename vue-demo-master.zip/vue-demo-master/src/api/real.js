import axios from "axios";

export default {
    getServers(cb, errorCb) {
        axios.get("http://10.167.152.149:10114/service/server", { timeout: 2000 })
            .then(res => cb(res.data.data))
            .catch(err => errorCb(err))
    }
}