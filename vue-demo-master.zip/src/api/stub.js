const _servers = [
    { "name": "服务器A", "ip": "192.168.1.1", "url": "http://192.168.1.1/" },
    { "name": "服务器B", "ip": "192.168.1.2", "url": "http://192.168.1.2/" }
];

export default {
    getServers(cb) {
        setTimeout(() => cb(_servers), 2000)
    }
}