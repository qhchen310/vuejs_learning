import VueRouter from 'vue-router'
import ServerList from '../components/ServerList.vue'

export default new VueRouter({
    // 设置路由映射
    routes: [
        { path: '/servers', component: ServerList },
    ]
})
