import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App.vue'
import { Layout, Menu, Table, Spin, message, Dropdown, Icon, Form, Input, Checkbox, Button } from 'ant-design-vue'
import store from './store'
import router from './router'

Vue.config.productionTip = false

// 安装路由器
Vue.use(VueRouter)

// 注册Antd组件
Vue.component(Layout.name, Layout)
Vue.component(Layout.Header.name, Layout.Header)
Vue.component(Layout.Content.name, Layout.Content)
Vue.component(Menu.name, Menu)
Vue.component(Menu.Item.name, Menu.Item)
Vue.component(Table.name, Table)
Vue.component(Spin.name, Spin)
Vue.component(Dropdown.name, Dropdown)
Vue.component(Dropdown.Button.name, Dropdown.Button)
Vue.component(Form.name, Form)
Vue.component(Form.Item.name, Form.Item)
Vue.component(Input.name, Input)
Vue.component(Icon.name, Icon)
Vue.component(Checkbox.name, Checkbox)
Vue.component(Button.name, Button)

// 映射message对象
Vue.prototype.$message = message

new Vue({
  // 安插Vuex
  store,
  // 安插Vue Router
  router,
  render: h => h(App),
}).$mount('#app')
