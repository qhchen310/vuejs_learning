export default function () {
    window.onload = function () {
        alert('test execute');
    }
}