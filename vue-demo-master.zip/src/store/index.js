import Vue from 'vue'
import Vuex from 'vuex'
import server from './modules/server'
import userLogin from './modules/userLogin'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

const state = {
    isAuthenticated: false,
    userInfo: null
}

const getters = {};

const mutations = {
    updateIsAuthenticatedState(state, data) {
        state.isAuthenticated = data ? true : false;
        state.userInfo = data;
    }
}
const actions = {
    initAuth: (context) => {
        const oauthInfo = localStorage.getItem('token');
        window.console.log(`initAuth execute,oauthInfo:${oauthInfo}`);
        context.commit('updateIsAuthenticatedState', oauthInfo);
    },
    resetAuth: (context, oauthInfo) => {
        localStorage.setItem('token', oauthInfo)
        window.console.log(`resetAuth execute,oauthInfo:${oauthInfo}`);
        context.commit('updateIsAuthenticatedState', oauthInfo);
    }
}

export default new Vuex.Store({
    state,
    getters,
    mutations,
    actions,
    // 模块定义
    modules: {
        server,
        userLogin
    },
    // 严格模式(debug时开启，production时关闭)
    strict: debug
})