import tokenUtils from '../../utils/tokenUtils';
import cookieUtils from '../../utils/cookieUtils';

// 状态定义
const state = {
    fetching: false,
    success: false,
    failure: false,
    error: null
}

// getter函数定义
const getters = {
    getRemember: (state) => {
        return state.remember;
    }
}

// 动作定义
const actions = {
    userLogin({ commit }, model) {
        return new Promise((resolve, reject) => {
            let { mailAddress, password, methodKind, remember } = model;
            if (remember) {
                cookieUtils.saveObject('email', mailAddress);
                cookieUtils.saveObject('password', password);
            } else {
                let date = new Date("October 13, 1975 11:13:00");
                cookieUtils.saveObject('email', '', date);
                cookieUtils.saveObject('password', '', date);
            }
            commit(types.INIT_REQUEST)
            tokenUtils.GetTokenInfoAsync(mailAddress, password, methodKind).then(value => {
                if (value.status === 200
                    && value.data) {
                    commit(types.INIT_SUCCESS);
                    resolve(value.data);
                } else {
                    window.console.log(`GetTokenInfoAsync error occur:${value.data.Message},errorCode:${value.data.ErrorCode}`);
                    commit(types.INIT_FAILURE, value.data);
                    reject();
                }
            }).catch(err => {
                window.console.log(`GetTokenInfoAsync error occur:${err}`);
                commit(types.INIT_FAILURE, err);
                reject();
            })
        });
    }
}

// 变更函数定义
const mutations = {
    loding(state) {
        state.fetching = true
    },
    loginSuccess(state) {
        state.fetching = false
        state.success = true
        state.failure = false
        state.error = null
    },
    loginFailure(state, { error }) {
        state.fetching = false
        state.failure = true
        state.error = error
    }
}

const types = {
    INIT_REQUEST: "loding",
    INIT_SUCCESS: "loginSuccess",
    INIT_FAILURE: "loginFailure"
}

export default {
    // 是否设定模块的命名空间
    namespaced: true,

    state,
    getters,
    actions,
    mutations
}