# Vue演示

## 必要的软件

- Nodejs
- VS Code

以上软件稳定版或者最新版都可以。

## 创建工程(非必须)

如果需要重新创建工程需要安装`vue-cli`，可以参考[官网](https://cli.vuejs.org/zh/)

注：建议安装`yarn`([官网](https://yarnpkg.com/zh-Hans/docs/install))，在本人机器上(Windows)使用`npm`安装一直失败

安装完毕后，该工程可以通过以下的命令创建。

```
vue create vue-demo
```

## 加载的组件

- vue
- vuex
- vue-router
- ant-design-vue
- axios

## 工程的自定义

从脚手架工具生成的HelloWorld修改成现在拥有一个服务器列表的样子。

### 结构

#### Vue入口
```
    App.vue
    main.js
```

#### 界面布局
```
    Layout.vue
```

#### 自定义组件
```
└─components
        ServerList.vue
```

#### Vuex定义
```
└─store
    │  index.js
    │
    └─modules
            server.js
```

#### 路由器
```
└─router
        index.js
```

#### 后台访问
```
└─api
        index.js
        real.js
        stub.js
```

### 使用Vue + Vuex

使用`Vuex`可以规范`state`的存取，会有更好的维护性，推荐在正式项目中使用。

### 使用`.env`和`.env.local`

脚手架工程的默认git设置会忽略掉`.env.local`。

可以在`.env.local`中定义个人开发环境的各种设置，加载后会覆盖`.env`中的内容，但又不用担心个人设置会被误传至git库中。

有一点要主要的是`.env`和`.env.local`中只有以`VUE_APP_`开头的键值对才会被加载至工程中。

### 使用antd for vue

干净简洁的UI设计，可以大大加快UI界面的开发速度。

更多UI选择，请参考 [UI设计](#UI设计) 章节

### 使用路由器

非单页面，稍微复杂一点采用页面布局的画面，路由器应该是必须要用的。

## 其他选择

### UI设计

目前为Vue提供UI支持的组件有不少，在此罗列一下，可以根据UI需要来进行选择。

- [Ant Design Vue](https://vue.ant.design/docs/vue/introduce-cn/)
- [vuetify](https://vuetifyjs.com/zh-Hans/)
- [Vue Material](https://vuematerial.io/)
- [Element](https://element.eleme.io/) ※js加载问题无法正常显示
- [Bootstrap + Vue](https://bootstrap-vue.js.org/)
- [Buefy](https://buefy.org/)

其中**vuetify**和**Vue Material**为Material系的UI。关于 [MATERIAL DESIGN](https://www.material.io/)

## 常用命令

### 初始化工程
```
yarn install
```

### 动态调试/修改
```
yarn run serve
```

### 编译发布版
```
yarn run build
```

### 执行测试
```
yarn run test
```

### 代码检查
```
yarn run lint
```