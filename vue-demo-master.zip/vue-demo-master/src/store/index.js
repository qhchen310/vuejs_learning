import Vue from 'vue'
import Vuex from 'vuex'
import server from './modules/server'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
    // 模块定义
    modules: {
        server
    },
    // 严格模式(debug时开启，production时关闭)
    strict: debug
})