 <template>
  <div>
    {{title}}
    <div id="swiperContainer" class="swiperContainer">
      <div id="sliderWrap" class="sliderWrap">
        <ul class="slider">
          <!-- <li>
            <p style="background-color:red"></p>
          </li>
          <li>
            <p style="background-color:red"></p>
          </li>
          <li>
            <p style="background-color:red"></p>
          </li>
          <li>
            <p style="background-color:red"></p>
          </li>
          <li>
            <p style="background-color:red"></p>
          </li> -->
        </ul>
      </div>
    </div>
  </div>
</template>
F
<script>
import testMoudle from '../scripts/testMoudle';
import { DoubleLinkLoopList, Node } from '../utils/doubleLinkLoopList';
export default {
  name: 'testMoudle',
  data() {
    return { title: 'testMoudle', list: this.init() }
  },
  methods: {
    init() {
      let list = new DoubleLinkLoopList();
      let segments = [{
        key: 1,
        color: 'red',
        data: 'one'
      }, {
        key: 2,
        color: 'red',
        data: 'two'
      }, {
        key: 3,
        color: 'red',
        data: 'three'
      }, {
        key: 4,
        color: 'red',
        data: 'four'
      }, {
        key: 5,
        color: 'red',
        data: 'five'
      }];
      let wrap = document.getElementById('sliderWrap');
      let ul = wrap.children[0];
      segments.forEach(element => {
        // view
        let li = document.createElement('li');
        li.appendChild(li.createElement(p));
        ul.appendChild(li);
        // logic
        list.Add(new Node(element));
      });
      list.Show();
      return list;
    }
  },
  created() {
    testMoudle();
  }
}
</script>
    
<style>
.swiperContainer {
  width: 900px;
  height: 650px;
  position: relative;
}

.slider li {
  position: absolute;
}

.slider li p {
  width: 50px;
  height: 50px;
}
</style>