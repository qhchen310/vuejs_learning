<template>
  <a-layout id="components-layout-demo-top-side-2">
    <a-layout-header class="header">
      <div class="logo">{{ title }}</div>
      <a-menu
        theme="dark"
        mode="horizontal"
        :style="{ lineHeight: '64px' }"
      >
        <a-menu-item key="1">
          <router-link to="/servers">服务器列表</router-link>
        </a-menu-item>
      </a-menu>
    </a-layout-header>
    <a-layout-content :style="{ background: '#fff', padding: '24px', margin: 0, minHeight: '280px' }">
      <router-view></router-view>
    </a-layout-content>
  </a-layout>
</template>

<script>
export default {
  data() {
    return {
      title: process.env.VUE_APP_TITLE
    }
  }
}
</script>

<style>
#components-layout-demo-top-side-2 .logo {
  width: 240px;
  height: 31px;
  font-size: 14pt;
  color: rgb(196,196,196);
  margin: 16px 28px 16px 0;
  float: left;
  line-height: 31px;
  text-align: center;
}
</style>