import axios from "axios";
import { WebApiGetADB2CAccessToken } from '../constants/settingConstants'


export default {
    GetTokenInfoAsync(mailAddress, password, methodKind) {
        return new Promise((resolve, reject) => {
            axios.post(WebApiGetADB2CAccessToken, {
                "mailaddress": mailAddress,
                "loginpassword": password,
                "method_Kind": methodKind
            }, {
                headers: {
                    "content-type": "application/json"
                },
                timeout: 20000
            })
                .then(res => resolve(res))
                .catch(err => reject(err))
        });
    }
}