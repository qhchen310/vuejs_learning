export class DoubleLinkLoopList {
    constructor() {
        this.nil = new Node({
            data: null
        });
        this.nil.next = this.nil;
        this.nil.prev = this.nil;
        this.tail = this.nil;
    }

    /**
     * EmptyOrNot 
     */
    IsEmpty() {
        return this.nil.next === this.nil;
    }

    /**
     * Search
     * @param {} node 
     */
    Search(node) {
        let x = this.nil.next;
        while (this.nil.next !== this.nil && x.key !== node.key) {
            x = x.next;
        }
        return x;
    }

    /**
     * Add Node
     * @param {*} node 
     */
    Add(node) {
        node.prev = this.tail;
        node.next = this.nil;
        this.tail.next = node;
        this.tail = node;
    }

    /**
     * Delete Node
     * @param {} node 
     */
    Delete(node) {
        node.prev.next = node.next;
        node.next.prev = node.prev;
    }

    /**
     * 
     */
    Show() {
        let x = this.nil.next;
        while (x !== this.nil) {
            window.console.log(`key:${x.key},value:${x.data}`);
            x = x.next;
        }
    }
}

/**
 * Node
 */
export class Node {
    constructor(node) {
        this.key = node.key;
        this.data = node.data;
        this.prev = null;
        this.next = null;
    }
}