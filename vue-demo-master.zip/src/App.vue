<template>
  <div id="app">
    <Layout />
  </div>
</template>

<script>
import Layout from "./Layout.vue";
import { mapActions } from "vuex";

export default {
  name: "app",
  components: {
    Layout,
  },
  methods: mapActions(["initAuth"]),
  created() {
    this.initAuth();
  },
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
