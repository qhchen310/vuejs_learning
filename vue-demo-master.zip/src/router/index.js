import VueRouter from 'vue-router'
import ServerList from '../components/ServerList.vue'
import UserLogin from '../components/UserLogin.vue'
import TestComponent from '../components/TestComponent.vue'

export default new VueRouter({
    // 设置路由映射
    routes: [{
        path: '/servers',
        component: ServerList
    },
    {
        path: '/login',
        component: UserLogin
    }, {
        path: '/test',
        component: TestComponent
    }]
})