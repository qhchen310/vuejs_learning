import api_stub from './stub'
import api_real from './real'

const useStub = process.env.VUE_APP_STUB === 'enable'
let api;

if (useStub) {
    api = api_stub
} else {
    api = api_real
}

export default api;