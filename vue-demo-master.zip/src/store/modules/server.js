import api from '../../api/'

// 状态定义
const state = {
    items: [],
    fetching: false,
    success: false,
    failure: false,
    error: null
}

// getter函数定义
const getters = {
    getServers: (state) => {
        return state.items;
    }
}

// 动作定义
const actions = {
    init({ commit }) {
        commit(types.INIT_REQUEST)
        api.getServers(
            (items) => commit(types.INIT_SUCCESS, { items: items }),
            (err) => commit(types.INIT_FAILURE, { error: err })
        )
    }
}

// 变更函数定义
const mutations = {
    fetchingServerItems(state) {
        state.items = []
        state.fetching = true
    },
    setServerItems(state, { items }) {
        state.items = items
        state.fetching = false
        state.success = true
    },
    setFailureStatus(state, { error }) {
        state.items = []
        state.fetching = false
        state.failure = true
        state.error = error
    }
}

const types = {
    INIT_REQUEST: "fetchingServerItems",
    INIT_SUCCESS: "setServerItems",
    INIT_FAILURE: "setFailureStatus"
}

export default {
    // 是否设定模块的命名空间
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}