export default {
    saveObject: (property, value, expireDate) => {
        let date = new Date();
        date.setDate(date.getDate() + expireDate);
        document.cookie = `${property}=${decodeURIComponent(value)}
        ${(expireDate === null) ? '' : ';expires=' + date.toGMTString()}`
    },
    getObject: (key) => {
        let value = null;
        if (document.cookie.length > 0) {
            let startIndex = -1;
            if ((startIndex = document.cookie.indexOf(`${key}=`)) > -1) {
                startIndex = startIndex + key.length + 1;
                let endIndex = document.cookie.indexOf(';', startIndex);
                if (endIndex > -1) {
                    return unescape(document.cookie.substring(startIndex, endIndex));
                }
            }
        }
        return value;
    },
    deleteObject() {

    }
}