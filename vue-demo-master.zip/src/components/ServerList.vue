<template>
    <div style="flex:1">
        <a-spin :spinning="fetching">
            <a-table
                :columns="columns"
                :rowKey="record => record.name"
                :dataSource="servers"
                bordered
            >
            </a-table>
        </a-spin>    
    </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

const columns = [{
    title: "名称",
    dataIndex: 'name'
}, {
    title: "IP",
    dataIndex: 'ip'
}, {
    title: "URL",
    dataIndex: 'url'
}]

export default {
    name: 'ServerList',
    computed: mapState({
        servers: state => state.server.items,
        fetching: state => state.server.fetching,
        success: state => state.server.success,
        failure: state => state.server.failure,
        error: state => state.server.error
    }),
    methods: mapActions('server', [
        // 映射 this.init() 到 this.$store.dispatch('server/init')
        'init'
    ]),
    mounted() {
        // this.$store.dispatch('server/init')
        this.init();
    },
    watch: {
        success: function(value) {
            if (value) {
                this.$message.success("数据取得成功")
            }
        },
        failure: function(value) {
            if (value) {
                this.$message.error(this.error.message)
            }
        }
    },
    data() {
        return {
            columns
        }
    }
}
</script>

<style scoped>
</style>
